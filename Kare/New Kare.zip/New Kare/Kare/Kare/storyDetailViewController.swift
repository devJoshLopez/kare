//
//  storyDetailViewController.swift
//  Kare
//
//  Created by Josh Lopez on 4/4/15.
//  Copyright (c) 2015 Josh Lopez. All rights reserved.
//

import UIKit

class storyDetailViewController: UIViewController {

    @IBOutlet weak var storyImageView: UIImageView!
    var story:Story!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        println(story.name)
        
        self.storyImageView.image = UIImage(named: story.image)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
