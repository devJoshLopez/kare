//
//  Story.swift
//  Kare
//
//  Created by Josh Lopez on 4/4/15.
//  Copyright (c) 2015 Josh Lopez. All rights reserved.
//

import Foundation

class Story {
    var name:String = ""
    var type:String = ""
    var location:String = ""
    var image:String = ""
    var isVisited:Bool = false
    
    init(name:String, type:String, location:String, image:String, isVisited:Bool) {
        self.name = name
        self.type = type
        self.location = location
        self.image = image
        self.isVisited = isVisited
    }
}