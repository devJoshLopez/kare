//
//  StoryFeedViewController.swift
//  Kare
//
//  Created by Josh Lopez on 4/3/15.
//  Copyright (c) 2015 Josh Lopez. All rights reserved.
//

import UIKit

class StoryFeedViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var storyFeedTableView: UITableView!
    
    
    var stories:[Story] = [
        Story(name: "Cafe Deadend", type: "Coffee & Tea Shop", location: "Hong Kong", image: "cafedeadend.jpg", isVisited: false),
        Story(name: "Homei", type: "Cafe", location: "Hong Kong", image: "homei.jpg", isVisited: false),
        Story(name: "Teakha", type: "Tea House", location: "Hong Kong", image: "teakha.jpg", isVisited: false),
        Story(name: "Cafe loisl", type: "Austrian / Causual Drink", location: "Hong Kong", image: "cafeloisl.jpg", isVisited: false),
        Story(name: "Petite Oyster", type: "French", location: "Hong Kong", image: "petiteoyster.jpg", isVisited: false),
        Story(name: "For Kee Restaurant", type: "Bakery", location: "Hong Kong", image: "forkeerestaurant.jpg", isVisited: false),
        Story(name: "Po's Atelier", type: "Bakery", location: "Hong Kong", image: "posatelier.jpg", isVisited: false),
        Story(name: "Bourke Street Backery", type: "Chocolate", location: "Sydney", image: "bourkestreetbakery.jpg", isVisited: false),
        Story(name: "Haigh's Chocolate", type: "Cafe", location: "Sydney", image: "haighschocolate.jpg", isVisited: false),
        Story(name: "Palomino Espresso", type: "American / Seafood", location: "Sydney", image: "palominoespresso.jpg", isVisited: false),
        Story(name: "Upstate", type: "American", location: "New York", image: "upstate.jpg", isVisited: false),
        Story(name: "Traif", type: "American", location: "New York", image: "traif.jpg", isVisited: false),
        Story(name: "Graham Avenue Meats", type: "Breakfast & Brunch", location: "New York", image: "grahamavenuemeats.jpg", isVisited: false),
        Story(name: "Waffle & Wolf", type: "Coffee & Tea", location: "New York", image: "wafflewolf.jpg", isVisited: false),
        Story(name: "Five Leaves", type: "Coffee & Tea", location: "New York", image: "fiveleaves.jpg", isVisited: false),
        Story(name: "Cafe Lore", type: "Latin American", location: "New York", image: "cafelore.jpg", isVisited: false),
        Story(name: "Confessional", type: "Spanish", location: "New York", image: "confessional.jpg", isVisited: false),
        Story(name: "Barrafina", type: "Spanish", location: "London", image: "barrafina.jpg", isVisited: false),
        Story(name: "Donostia", type: "Spanish", location: "London", image: "donostia.jpg", isVisited: false),
        Story(name: "Royal Oak", type: "British", location: "London", image: "royaloak.jpg", isVisited: false),
        Story(name: "Thai Cafe", type: "Thai", location: "London", image: "thaicafe.jpg", isVisited: false),
        ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Empty back button title
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .Plain, target: nil, action: nil)
        
        self.storyFeedTableView.dataSource = self
        self.storyFeedTableView.delegate = self
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stories.count
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "StoryCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as StoryTableViewCell
        
        let story = stories[indexPath.row]
        cell.titleLabel.text = story.name
        cell.distanceLabel.text = "476 Miles"
        
        cell.titleBackgroundVisualEffect.layer.cornerRadius = 7
        cell.titleBackgroundVisualEffect.layer.borderColor = UIColor.grayColor().colorWithAlphaComponent(0.5).CGColor
        cell.titleBackgroundVisualEffect.layer.borderWidth = 0.1
        cell.titleBackgroundVisualEffect.clipsToBounds = true
        
        return cell
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showStoryDetail" {
            if let indexPath = self.storyFeedTableView.indexPathForSelectedRow() {
                let destinationController = segue.destinationViewController as storyDetailViewController
                destinationController.story = stories[indexPath.row]
            }
        }
    }
    
    
//    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//        
//        println(indexPath)
//        
//        // Create an option menu as an action sheet
//        let optionMenu = UIAlertController(title: "Something!", message: "What do you want to do?", preferredStyle: .ActionSheet)
//        
//        // Add actions to the menu
//        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel , handler: nil)
//        optionMenu.addAction(cancelAction)
//        
//        // Display the menu
//        self.presentViewController(optionMenu, animated: true, completion: nil)
//    }
    
    
//    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
//        
//    }

}

